class NodeData(object):
    """
    A class that helps convey accessory information like
    column no and class number for a node easily.
    """

    def __init__(self, txt, lineNo=None, colNo=None, other=None):
        self.text = txt
        self.lineNo = lineNo
        self.colNo = colNo
        self.other = other

    def __str__(self):
        return self.text

    # def __repr__(self):
    #   return self.text
