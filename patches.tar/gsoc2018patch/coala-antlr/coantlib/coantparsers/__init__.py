"""
This directory holds means to get generic information for specific languages.
"""

# Start ignoring PyUnusedCodeBear
from .Python3 import Python3Parser, Python3Lexer
# Stop ignoring PyUnusedCodeBear
