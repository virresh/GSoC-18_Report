from coalib.bearlib.languages.Language import Language
from coantlib.ASTLoader import ASTLoader
from coantlib.mapper import parser_map
from importlib import import_module


class ASTWalker():
    """
    Base class for methods on walker
    """
    treeRoot = None
    tree = None

    @staticmethod
    def get_walker(lang):
        """
        Todo: implement this method to resolve walkers depending
        on the parameters
        """
        y = Language[lang].__class__
        x = import_module(parser_map[y][2])  # third element is walker module
        return getattr(x, parser_map[y][3])  # fourth element is class name

    def __init__(self, file, filename, lang='auto'):
        self.tree = ASTLoader.loadFile(file, filename, lang)
        self.treeRoot = self.tree.file_input()
