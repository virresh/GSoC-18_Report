from coalib.bearlib.languages.definitions import *
from coantlib.coantparsers import *


parser_map = {
    Python.Python: (Python3Lexer,
                    Python3Parser,
                    'coantlib.coantwalkers.Py3Walker',
                    'Py3Walker',
                    ),
}
