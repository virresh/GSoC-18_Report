from coantlib.ASTWalker import ASTWalker
from coalib.bears.LocalBear import LocalBear


class ASTBear(LocalBear):
    def run(self,
            filename,
            file,
            lang='auto'):
        if lang == 'auto':
            lang = filename.split('.')[-1]
            self.walker = ASTWalker.get_walker(lang)(filename, file, lang)
        else:
            self.walker = ASTWalker.get_walker(lang)(filename, file, lang)
