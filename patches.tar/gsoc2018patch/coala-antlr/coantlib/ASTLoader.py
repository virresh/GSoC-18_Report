from antlr4 import InputStream, CommonTokenStream
from coalib.bearlib.languages.Language import Language
from coantlib.mapper import parser_map


class ASTLoader():
    @staticmethod
    def loadFile(file, filename, lang='auto'):
        """
        Loads file's AST into memory
        """
        language_class = Language[lang]

        # The newline at end is due to limitations of ANTLR
        # grammar for Python, needs to be removed at upstream before
        # removal from the library
        contents = ''.join(file)
        if len(file) == 0 or contents[-1] != '\n':
            contents = contents + '\n'
        our_map = parser_map[language_class.__class__]

        lexer = our_map[0](InputStream(contents))
        tokenisedInputStream = CommonTokenStream(lexer)
        parser = our_map[1](tokenisedInputStream)

        return parser
