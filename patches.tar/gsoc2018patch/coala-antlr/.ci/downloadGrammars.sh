set -e
cd "${0%/*}"
mkdir grammars
curl https://raw.githubusercontent.com/antlr/grammars-v4/master/python3-py/Python3.g4 > grammars/Python3.g4
