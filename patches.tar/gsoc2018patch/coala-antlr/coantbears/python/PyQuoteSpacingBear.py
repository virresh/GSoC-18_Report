from coantlib.ASTBear import ASTBear
from coalib.results.Result import Result


class PyQuoteSpacingBear(ASTBear):

    LANGUAGES = {'Python 3'}
    CAN_DETECT = {'Formatting'}

    def run(self,
            filename,
            file,
            min_str_len=3):
        super(PyQuoteSpacingBear, self).run(filename,
                                            file,
                                            lang=list(self.LANGUAGES)[0],
                                            )
        quoteContent = self.walker.get_quote_content()
        for content in quoteContent:
            if str(content)[-2] == ' ' and len(str(content)) > min_str_len:
                yield Result.from_values(
                    origin=self,
                    message=('Line {} has a string with trailing space '
                             '{}').format(content.lineNo, content.colNo),
                    file=filename,
                    line=content.lineNo,
                    column=content.colNo,
                    end_line=content.lineNo,
                    end_column=content.colNo+len(content.text))
